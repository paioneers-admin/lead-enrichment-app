"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import {
  Users,
  Linkedin,
  Globe,
  User,
  CheckCircle,
  AlertCircle,
  Loader2,
  Phone,
  Mail,
  MessageSquare,
  RefreshCw,
} from "lucide-react"

const CLAY_WEBHOOK_URL =
  "https://api.clay.com/v3/sources/webhook/pull-in-data-from-a-webhook-c77750f7-aab7-4e3e-ae4a-3eff89a1bc9b"

interface FormData {
  linkedinUrl: string
  companyUrl: string
  requestorName: string
}

interface FormErrors {
  linkedinUrl?: string
  companyUrl?: string
  requestorName?: string
}

interface EnrichedLead {
  id: string
  receivedAt: string
  linkedin_url?: string
  company_url?: string
  requestor_name?: string
  phone?: string
  email?: string
  script?: string
  [key: string]: any
}

export default function LeadEnrichmentForm() {
  const [formData, setFormData] = useState<FormData>({
    linkedinUrl: "",
    companyUrl: "",
    requestorName: "",
  })
  const [errors, setErrors] = useState<FormErrors>({})
  const [isLoading, setIsLoading] = useState(false)
  const [isSuccess, setIsSuccess] = useState(false)
  const [submitError, setSubmitError] = useState("")
  const [enrichedLeads, setEnrichedLeads] = useState<EnrichedLead[]>([])
  const [isLoadingLeads, setIsLoadingLeads] = useState(false)

  const fetchEnrichedLeads = async () => {
    setIsLoadingLeads(true)
    try {
      const response = await fetch("/api/clay-webhook")
      if (response.ok) {
        const data = await response.json()
        setEnrichedLeads(data.leads || [])
      }
    } catch (error) {
      console.error("[v0] Error fetching enriched leads:", error)
    } finally {
      setIsLoadingLeads(false)
    }
  }

  useEffect(() => {
    fetchEnrichedLeads()
  }, [])

  const validateUrl = (url: string, type: "linkedin" | "company"): string | undefined => {
    if (!url.trim()) {
      return `${type === "linkedin" ? "LinkedIn" : "Company"} URL is required`
    }

    try {
      const urlObj = new URL(url)
      if (type === "linkedin" && !urlObj.hostname.includes("linkedin.com")) {
        return "Please enter a valid LinkedIn URL"
      }
      if (!urlObj.protocol.startsWith("http")) {
        return "URL must start with http:// or https://"
      }
    } catch {
      return "Please enter a valid URL"
    }

    return undefined
  }

  const validateForm = (): boolean => {
    const newErrors: FormErrors = {}

    newErrors.linkedinUrl = validateUrl(formData.linkedinUrl, "linkedin")
    newErrors.companyUrl = validateUrl(formData.companyUrl, "company")

    if (!formData.requestorName.trim()) {
      newErrors.requestorName = "Your name is required"
    }

    setErrors(newErrors)
    return !Object.values(newErrors).some((error) => error)
  }

  const handleInputChange = (field: keyof FormData, value: string) => {
    setFormData((prev) => ({ ...prev, [field]: value }))
    // Clear error when user starts typing
    if (errors[field]) {
      setErrors((prev) => ({ ...prev, [field]: undefined }))
    }
    setSubmitError("")
    setIsSuccess(false)
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!validateForm()) {
      return
    }

    setIsLoading(true)
    setSubmitError("")

    try {
      // Use CORS proxy to bypass V0's strict CSP
      const proxyUrl = "https://corsproxy.io/?"
      const targetUrl = encodeURIComponent(CLAY_WEBHOOK_URL)

      const response = await fetch(proxyUrl + targetUrl, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          linkedin_url: formData.linkedinUrl,
          company_url: formData.companyUrl,
          requestor_name: formData.requestorName,
          submitted_at: new Date().toISOString(),
        }),
      })

      if (response.ok) {
        setIsSuccess(true)
        setFormData({ linkedinUrl: "", companyUrl: "", requestorName: "" })
        setTimeout(() => {
          fetchEnrichedLeads()
        }, 2000) // Wait 2 seconds to allow Clay to process
      } else {
        throw new Error(`HTTP ${response.status}`)
      }
    } catch (error) {
      setSubmitError("Error sending data to Clay. Please try again.")
      console.error("Clay webhook error:", error)
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="min-h-screen bg-background dark">
      <div className="bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 min-h-screen">
        <div className="max-w-6xl mx-auto px-4 py-12">
          {/* Header Section */}
          <div className="text-center space-y-6 mb-12">
            <div className="flex items-center justify-center gap-3 mb-6">
              <div className="p-3 bg-primary/10 rounded-xl">
                <Users className="h-8 w-8 text-primary" />
              </div>
              <h1 className="text-4xl md:text-5xl font-bold text-white">Lead Enrichment</h1>
            </div>
            <p className="text-xl text-slate-300 max-w-2xl mx-auto leading-relaxed">
              Transform your leads into actionable insights. Get enriched contact data with phone numbers, email
              addresses, and personalized outreach scripts.
            </p>
          </div>

          <div className="grid lg:grid-cols-2 gap-8">
            {/* Main Form Card */}
            <Card className="bg-slate-800/50 border-slate-700 backdrop-blur-sm shadow-2xl">
              <CardHeader className="text-center pb-8">
                <CardTitle className="text-2xl text-white flex items-center justify-center gap-2">
                  <Globe className="h-6 w-6 text-primary" />
                  Enrich Your Lead
                </CardTitle>
                <CardDescription className="text-slate-400 text-lg">
                  Provide the information below to get comprehensive lead data
                </CardDescription>
              </CardHeader>

              <CardContent className="space-y-6">
                {/* Success Message */}
                {isSuccess && (
                  <div className="bg-green-500/10 border border-green-500/20 rounded-lg p-4 flex items-start gap-3">
                    <CheckCircle className="h-5 w-5 text-green-400 mt-0.5 flex-shrink-0" />
                    <div>
                      <p className="text-green-400 font-medium">
                        Lead sent for enrichment! Clay is now processing your request.
                      </p>
                      <p className="text-green-300/80 text-sm mt-1">
                        You'll receive the enriched data with phone, email, and scripts shortly.
                      </p>
                    </div>
                  </div>
                )}

                {/* Error Message */}
                {submitError && (
                  <div className="bg-red-500/10 border border-red-500/20 rounded-lg p-4 flex items-start gap-3">
                    <AlertCircle className="h-5 w-5 text-red-400 mt-0.5 flex-shrink-0" />
                    <p className="text-red-400">{submitError}</p>
                  </div>
                )}

                <form onSubmit={handleSubmit} className="space-y-6">
                  {/* LinkedIn URL */}
                  <div className="space-y-2">
                    <Label htmlFor="linkedinUrl" className="text-white flex items-center gap-2">
                      <Linkedin className="h-4 w-4 text-blue-400" />
                      LinkedIn Profile URL
                    </Label>
                    <Input
                      id="linkedinUrl"
                      type="url"
                      placeholder="https://linkedin.com/in/username"
                      value={formData.linkedinUrl}
                      onChange={(e) => handleInputChange("linkedinUrl", e.target.value)}
                      className="bg-slate-700/50 border-slate-600 text-white placeholder:text-slate-400 focus:border-primary focus:ring-primary/20"
                      disabled={isLoading}
                    />
                    {errors.linkedinUrl && (
                      <p className="text-red-400 text-sm flex items-center gap-1">
                        <AlertCircle className="h-3 w-3" />
                        {errors.linkedinUrl}
                      </p>
                    )}
                  </div>

                  {/* Company URL */}
                  <div className="space-y-2">
                    <Label htmlFor="companyUrl" className="text-white flex items-center gap-2">
                      <Globe className="h-4 w-4 text-green-400" />
                      Company Website URL
                    </Label>
                    <Input
                      id="companyUrl"
                      type="url"
                      placeholder="https://company.com"
                      value={formData.companyUrl}
                      onChange={(e) => handleInputChange("companyUrl", e.target.value)}
                      className="bg-slate-700/50 border-slate-600 text-white placeholder:text-slate-400 focus:border-primary focus:ring-primary/20"
                      disabled={isLoading}
                    />
                    {errors.companyUrl && (
                      <p className="text-red-400 text-sm flex items-center gap-1">
                        <AlertCircle className="h-3 w-3" />
                        {errors.companyUrl}
                      </p>
                    )}
                  </div>

                  {/* Requestor Name */}
                  <div className="space-y-2">
                    <Label htmlFor="requestorName" className="text-white flex items-center gap-2">
                      <User className="h-4 w-4 text-purple-400" />
                      Your Full Name
                    </Label>
                    <Input
                      id="requestorName"
                      type="text"
                      placeholder="Your full name"
                      value={formData.requestorName}
                      onChange={(e) => handleInputChange("requestorName", e.target.value)}
                      className="bg-slate-700/50 border-slate-600 text-white placeholder:text-slate-400 focus:border-primary focus:ring-primary/20"
                      disabled={isLoading}
                    />
                    {errors.requestorName && (
                      <p className="text-red-400 text-sm flex items-center gap-1">
                        <AlertCircle className="h-3 w-3" />
                        {errors.requestorName}
                      </p>
                    )}
                  </div>

                  {/* Submit Button */}
                  <Button
                    type="submit"
                    disabled={isLoading}
                    className="w-full bg-primary hover:bg-primary/90 text-primary-foreground font-semibold py-3 text-lg transition-all duration-200 hover:shadow-lg hover:shadow-primary/25"
                  >
                    {isLoading ? (
                      <>
                        <Loader2 className="h-5 w-5 mr-2 animate-spin" />
                        Enriching Lead...
                      </>
                    ) : (
                      <>
                        <Users className="h-5 w-5 mr-2" />
                        Enrich Lead Data
                      </>
                    )}
                  </Button>
                </form>

                {/* Info Section */}
                <div className="bg-slate-700/30 rounded-lg p-4 mt-8">
                  <h3 className="text-white font-medium mb-2">What you'll receive:</h3>
                  <ul className="text-slate-300 text-sm space-y-1">
                    <li>• Direct phone numbers and email addresses</li>
                    <li>• Company insights and key decision makers</li>
                    <li>• Personalized outreach scripts and talking points</li>
                  </ul>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-slate-800/50 border-slate-700 backdrop-blur-sm shadow-2xl">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle className="text-2xl text-white flex items-center gap-2">
                    <CheckCircle className="h-6 w-6 text-green-400" />
                    Enriched Results
                  </CardTitle>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={fetchEnrichedLeads}
                    disabled={isLoadingLeads}
                    className="border-slate-600 text-slate-300 hover:bg-slate-700 bg-transparent"
                  >
                    {isLoadingLeads ? <Loader2 className="h-4 w-4 animate-spin" /> : <RefreshCw className="h-4 w-4" />}
                  </Button>
                </div>
                <CardDescription className="text-slate-400">Latest enriched lead data from Clay</CardDescription>
              </CardHeader>

              <CardContent className="space-y-4 max-h-[600px] overflow-y-auto">
                {enrichedLeads.length === 0 ? (
                  <div className="text-center py-8">
                    <Users className="h-12 w-12 text-slate-500 mx-auto mb-4" />
                    <p className="text-slate-400">No enriched leads yet</p>
                    <p className="text-slate-500 text-sm">Submit a lead above to see results here</p>
                  </div>
                ) : (
                  enrichedLeads.map((lead) => (
                    <div key={lead.id} className="bg-slate-700/30 rounded-lg p-4 space-y-3">
                      <div className="flex items-center justify-between">
                        <Badge variant="secondary" className="bg-green-500/10 text-green-400 border-green-500/20">
                          Enriched
                        </Badge>
                        <span className="text-slate-400 text-xs">{new Date(lead.receivedAt).toLocaleString()}</span>
                      </div>

                      <div className="space-y-2">
                        {lead.requestor_name && (
                          <div className="flex items-center gap-2">
                            <User className="h-4 w-4 text-purple-400" />
                            <span className="text-white font-medium">{lead.requestor_name}</span>
                          </div>
                        )}

                        {lead.phone && (
                          <div className="flex items-center gap-2">
                            <Phone className="h-4 w-4 text-green-400" />
                            <span className="text-slate-300">{lead.phone}</span>
                          </div>
                        )}

                        {lead.email && (
                          <div className="flex items-center gap-2">
                            <Mail className="h-4 w-4 text-blue-400" />
                            <span className="text-slate-300">{lead.email}</span>
                          </div>
                        )}

                        {lead.script && (
                          <div className="space-y-1">
                            <div className="flex items-center gap-2">
                              <MessageSquare className="h-4 w-4 text-yellow-400" />
                              <span className="text-white font-medium">Outreach Script:</span>
                            </div>
                            <p className="text-slate-300 text-sm bg-slate-800/50 rounded p-2 ml-6">{lead.script}</p>
                          </div>
                        )}
                      </div>

                      {(lead.linkedin_url || lead.company_url) && (
                        <>
                          <Separator className="bg-slate-600" />
                          <div className="flex flex-wrap gap-2">
                            {lead.linkedin_url && (
                              <a
                                href={lead.linkedin_url}
                                target="_blank"
                                rel="noopener noreferrer"
                                className="text-blue-400 hover:text-blue-300 text-xs flex items-center gap-1"
                              >
                                <Linkedin className="h-3 w-3" />
                                LinkedIn
                              </a>
                            )}
                            {lead.company_url && (
                              <a
                                href={lead.company_url}
                                target="_blank"
                                rel="noopener noreferrer"
                                className="text-green-400 hover:text-green-300 text-xs flex items-center gap-1"
                              >
                                <Globe className="h-3 w-3" />
                                Company
                              </a>
                            )}
                          </div>
                        </>
                      )}
                    </div>
                  ))
                )}
              </CardContent>
            </Card>
          </div>

          <div className="text-center mt-8 space-y-2">
            <p className="text-slate-400 text-sm">Powered by advanced lead enrichment technology</p>
            <div className="bg-slate-800/30 rounded-lg p-3 max-w-2xl mx-auto">
              <p className="text-slate-300 text-xs font-medium mb-1">Clay Webhook URL:</p>
              <code className="text-slate-400 text-xs break-all">{window.location.origin}/api/clay-webhook</code>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
