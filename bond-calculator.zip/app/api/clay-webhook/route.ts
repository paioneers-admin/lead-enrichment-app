import { type NextRequest, NextResponse } from "next/server"

// In-memory storage for demo purposes
// In production, you'd use a database
let enrichedLeads: any[] = []

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()

    console.log("[v0] Received Clay webhook data:", body)

    // Store the enriched data
    const enrichedLead = {
      id: Date.now().toString(),
      receivedAt: new Date().toISOString(),
      ...body,
    }

    enrichedLeads.unshift(enrichedLead) // Add to beginning of array

    // Keep only the last 50 leads
    if (enrichedLeads.length > 50) {
      enrichedLeads = enrichedLeads.slice(0, 50)
    }

    console.log("[v0] Stored enriched lead:", enrichedLead)

    return NextResponse.json({ success: true, message: "Data received successfully" })
  } catch (error) {
    console.error("[v0] Error processing Clay webhook:", error)
    return NextResponse.json({ success: false, error: "Failed to process webhook data" }, { status: 500 })
  }
}

export async function GET() {
  // Return the stored enriched leads
  return NextResponse.json({ leads: enrichedLeads })
}
